# v2.3.0 — Visio export rewritten, Visio import added, better drawing

## Visio (.vsdx) export, rebuilt for Visio 2016 / 2019 / LTSC 2021 / Microsoft 365

The v2.2 / v2.2.1 export was rejected by Visio. The main causes were:

- **Wrong element order inside shapes.** Visio requires every shape to list its cells first, then its sections, then foreign data, then text. The old writer put text cells (`TxtWidth`, `TxtHeight`, `TxtPinX` …) after the Geometry and Connection sections, and put `<Text>` before `<ForeignData>` on pictures.
- **Missing parts that Visio writes.** The package had no Visio style sheets, document properties or window settings, and connectors had no connector master.
- **Hand-made connectors.** Connectors were plain 1-D shapes, so Visio could not route or re-glue them.

How the new writer works:

- It builds the file the way Visio itself saves one. It reuses style sheets and the **Dynamic connector** master that were saved by Microsoft Visio (from the BSD-licensed `vsdx` project template). It also adds `docProps` and `windows.xml`.
- Cells come before sections, which come before text, in every shape.
- **Devices** become real vector symbols: the coloured tile plus the router, switch or firewall glyph, drawn as Visio geometry so they can be resized and recoloured.
  - The hostname, role and info appear under the symbol, like Visio's network stencils.
  - The same values are stored in **Shape Data**: Hostname, Device type, Role, Info, IP, Subnet, VLAN and Notes.
- **Links** become Visio dynamic connectors, **glued** to the devices. Moving a device in Visio drags its links along.
  - Pinned ends glue to the matching connection point.
  - Straight, elbow and curved routes are mapped to Visio's route styles.
  - Arrowheads, colour, weight and dash are kept.
  - Port labels are stored as Shape Data (A-end / B-end port) and are also drawn as labels.
- **Clouds** are exported as real puffy cloud outlines (Bézier curves), not ellipses.
- **Pencil strokes** are exported as smooth curves.
- **Zones, notes, text and pictures** (PNG/JPEG/GIF/BMP) become editable Visio shapes.
- Each Idea Board page becomes a Visio page.

How it was checked (Visio itself was not available):

- The output was checked against files saved by Visio.
- Every part is well-formed XML.
- Element order was verified in every shape.
- Every cell name was checked against those used in Visio-saved files.
- Files open and render correctly in LibreOffice Draw (libvisio) and in the python `vsdx` reader.

## New: Visio import

- Use **Menu ▸ Import Visio (.vsdx)…**, or drop a `.vsdx` file onto the canvas. Each Visio page becomes an Idea Board page in a new board.
- **Files exported by Idea Board come back exactly:** devices, roles, link types, ports and styles.
- **Changes made in Visio are kept on re-import:** moved shapes, edited text, and links re-glued in Visio.
- **Other Visio drawings are converted:**
  - rectangles, ellipses and diamonds
  - text
  - connectors, with their glue
  - pictures
  - containers become zones
  - pencil-like lines
  - stencil shapes whose name says router, switch, firewall, server, AP, phone and so on become Idea Board devices
- The importer understands:
  - masters and groups (including nested groups and rotated or flipped shapes)
  - text position and alignment
  - deflate-compressed packages
- Old binary `.vsd` files are not supported. Save them as `.vsdx` in Visio first.

## Drawing (the tldraw feel is unchanged)

- **Clouds** are drawn tldraw-style: even round puffs that stay round when the cloud is wide. They now also get the hand-drawn outline in the "draw" dash style.
- **Arrowheads:** choose triangle, open arrow, dot, diamond or bar in the style panel. New arrows use your last choice.
- **Elbow links respect the side they are pinned to.** A link pinned to the top, right, bottom or left of a shape leaves and enters square-on, with a clean L or Z path.
- **Alt + drag** draws a box, ellipse, diamond, cloud or zone from its centre. **Shift + drag** still makes squares and circles.
- **Shift + drag on an arrow** now snaps in 15° steps, like tldraw. Before, it snapped in 45° steps.
- Diamond and ellipse labels get a little more room, so short words don't break.
- The help panel (`?`) lists the new shortcuts.

## Unchanged

Pencil, eraser, laser, pages, boards, search, PDF/PNG/SVG export, keyboard connect, the team-server mode, and saved-board compatibility. Older `.ideaboard.json` files open as before.
