# Idea Board

A self-hosted whiteboard for network diagrams — routers, switches, firewalls, WAN
circuits and the links between them. It feels like tldraw (infinite canvas, bottom
toolbar, floating style panel) and has network-specific parts built in.

One file (`index.html`) with no dependencies, no build step and no calls to outside
services. It runs offline and works on an air-gapped server.

## Run it

**Docker (recommended)**

```bash
docker compose up -d --build
# open http://<server>:8080
```

**Any web server** — copy `index.html` into a web root (nginx, Apache, IIS, Caddy).

**Quick test** — `python3 -m http.server 8080` in this folder, or just open `index.html`
in a browser.

To put it behind an existing nginx reverse proxy at a sub-path:

```nginx
location /ideaboard/ { proxy_pass http://127.0.0.1:8080/; }
```

## Features

- Infinite canvas: pan (wheel, Space-drag, H), zoom (Ctrl + wheel, pinch), dot grid, snap to grid
- Network library: router, L3 switch, switch, firewall, load balancer, server, ISE/NAC,
  AP, WLC, NTE/CPE, endpoint, IP phone; Internet / MPLS / cloud; zones (site frames)
- **Links bind to devices** and follow them when you move them. They can be straight,
  curved (drag the middle handle) or elbow.
- Link types: Ethernet, single-mode fibre (yellow), multimode fibre (orange), 802.1Q trunk, port-channel/vPC, WAN circuit, VPN, OOB management
- Link label (e.g. `CCT-10023 · 1G`) plus **A-end and B-end port labels** (e.g. `Te1/1/1`, `Eth1/49`)
- Device hostname, a free-text info block (mgmt IP, model, code version), and a
  **role badge** (CL / DL / AG / ML / AS / WAN / DMZ)
- Zones act like frames: moving a zone moves the devices inside it
- Hand-drawn (tldraw-style) or clean outlines for shapes; pencil with smooth, pressure-sensitive strokes (P); eraser (E); arrows
- **Boards**: keep many boards in the browser (Boards button next to the menu): create, switch, rename, duplicate, delete
- **Laser pointer (K)**: works like tldraw's. The red trail stays while you keep pointing, then fades 1.2 s after you stop. It is never saved.
- Pages: several pages per board, each numbered with an optional unique name (e.g. "Page 1 · Mexico", "Page 2 · Cisco"). Use the page menu next to the board name; PageUp / PageDown switch pages
- Alignment guides that snap edges and centres to other shapes (hold Ctrl to skip); tool lock (Q)
- Align, distribute, duplicate (Ctrl D or Alt-drag), copy/paste between tabs, undo/redo
- Autosaves in the browser; save and open `.ideaboard.json` files; export PNG or SVG
  (exports only the selection when something is selected)
- Light and dark themes

Press `?` in the app to see all shortcuts.

## Where data lives

The app autosaves every board, with all its pages, in the browser's `localStorage` on that machine. Boards are separate per browser and per computer, and clearing browser site data removes them. Use **Menu → Save
to file** to keep or share a board (the files are plain JSON and work well in git).
Server-side storage and multi-user editing are possible next steps.

## Customising

Everything is in `index.html`:
- `DEVICES` — add device types. Icons are SVG paths drawn on a 48×48 grid.
- `LINKS` — link-type presets (colour, dash, width).
- `ROLES` — role badge names and colours.
- `COLORS` — the palette (light and dark values).

Licence: MIT.
