# Idea Board v2.3.0

Open **IdeaBoard-v2.3.0.html** in Chrome or Edge. It works offline and needs no installation.

Before you switch versions:

1. In your current version, use **Menu ▸ Save to file**.
2. In v2.3.0, use **Menu ▸ Open file as new board** to load that file.

## Visio

### Export

1. Go to **Menu ▸ Export Visio (.vsdx)…**.
2. Choose **All pages** or **Current page**.
3. Click **Download .vsdx**.

Open the file in Visio LTSC 2021 (or Visio 2016, 2019 or Microsoft 365).

What you get in Visio:

| In Idea Board | In Visio |
|---|---|
| Device | Vector symbol (tile + glyph) with hostname, role and info under it. The same values are in **Shape Data** (right-click ▸ Data ▸ Shape Data). |
| Link / arrow | **Dynamic connector** glued to the devices, so it follows them when you move them. Route style, arrowheads, colour, dash and weight are kept. Port labels are in Shape Data and also drawn as labels. |
| Cloud | Cloud outline |
| Zone | Rounded dashed frame with its title at the top left |
| Rectangle, ellipse, diamond, note, text | Matching Visio shapes |
| Pencil stroke | Smooth curve |
| Picture | Embedded picture |

### Import

Use **Menu ▸ Import Visio (.vsdx)…**, or drag a `.vsdx` file onto the canvas. The drawing opens as a new board, with one page per Visio page.

- **A file exported from Idea Board** comes back exactly, including anything you changed in Visio: positions, sizes, text and re-glued links.
- **A file made in Visio** is converted:
  - Boxes, ellipses, diamonds, text, connectors (with their glue), pictures and containers are converted to the matching Idea Board shapes.
  - Network stencil shapes whose name contains *router, switch, firewall, server, access point, phone* and so on become Idea Board devices.
  - Complex stencil artwork is simplified.
- Old binary `.vsd` files must be saved as `.vsdx` in Visio first.

### Example files

- **Example-network.vsdx** is the built-in sample network.
- **Example-all-shapes.vsdx** has two pages with every object type.

Open them in Visio to check your setup.

## What's new

See **CHANGELOG.md**.

## Checking and limits

Microsoft Visio was not available while this version was built.

Instead, the export was:

- built to match the structure of files saved by Visio 2016;
- checked part by part: XML, element order, cell names, relationships and content types;
- opened in LibreOffice Draw and in the python `vsdx` library;
- round-tripped through Idea Board's own importer.

If Visio still reports a problem, note the exact message and which example file it was. That pinpoints the part to fix.

Known differences in Visio:

- Shapes use clean lines rather than the hand-drawn outline.
- Links may re-route when you move shapes, because they are Visio dynamic connectors.
